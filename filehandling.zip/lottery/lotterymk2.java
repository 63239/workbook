import java.util.Scanner;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

public class lotterymk2
{
        public static void main(String[] args) throws IOException
        {
            boolean lotteryNumbers[] = new boolean[51];
            int numberOfSelectedBalls = 0;
            int winningBall = 0;
            do{
                do{
                    winningBall = (int)Math.ceil(Math.random()*50);
                }while (winningBall==0);
                if(lotteryNumbers[winningBall] == false){
                    lotteryNumbers[winningBall] = true;
                    numberOfSelectedBalls++;
                }
            }while (numberOfSelectedBalls != 6);
            FileWriter fw = new FileWriter("U:\\computing\\lottery.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            for (int i = 0; i <50; i++){
                if (lotteryNumbers[i]==true){
                    bw.write(i + "\t");
                }
            }
            bw.close();
        }
    }
