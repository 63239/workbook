import java.util.Scanner;
public class lottery
{

    public static boolean ismatch(int guess, int[] list, int number) {
        boolean found = false;
        
        if (number > 0) {
            int i = 0;
            while (i < number) {
                if (list[i] == guess) {
                    found = true;
                }
                i++;
            }
        }
        
        return found;
    }
    
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Lottery!");

        // rewards based on number of matches
        // last reward is for 5 matches plus bonus ball match
        int rewards[] = new int[]{0, 0, 0, 10, 100, 10000, 1000000, 100000};
        
        // pick six random balls
        int ball[] = new int[6];
        int bonus;
        int newball;
        for (int i = 0; i < 6; i++) {
            do {
                newball = (int)Math.ceil(Math.random()*49);
            }
            while (ismatch(newball, ball, i));
            ball[i] = newball;
        }
        
        // pick the bonus ball
        do {
            bonus = (int)Math.ceil(Math.random()*49);
        }
        while (ismatch(bonus, ball, 6));
        
        System.out.println(bonus);
        
        // request the 6 guesses
        int guess[] = new int[6];
        for (int i = 0; i < 6; i++) {
                boolean valid = false;
                do {
                    System.out.println("please enter a number between 1 and 49");
                    guess[i] = input.nextInt();
                    if (guess[i] >= 1 && guess[i] <= 49) {
                        if (ismatch(guess[i], guess, i)) {
                            System.out.println("already guessed");
                        }
                        else {
                            valid = true;
                        }
                    }
                    else {
                        System.out.println("invalid number");
                    }
           
                } while (!valid);
        }
        
        // display the guesses
        for (int i = 0; i < 6; i++) {
            System.out.println(guess[i]);
        }
        
        // check how many guesses match standard 6 balls
        int matches = 0;
        for (int i = 0; i < 6; i++) {
            if (ismatch(guess[i], ball, 6)) {
                matches++;
            }
        }
        
        // if there were 5 mathces then check the bonus ball
        if (ismatch(bonus, guess, 6)) {
            matches += 2;
        }
        int amountwon = rewards[matches];
        if (amountwon == 0) {
            System.out.println("Sorry, no win today.");
        }
        else {
            System.out.print("You won! £");
            System.out.println(amountwon);
        }
    }
}