import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class searchTerm
{
        public static void searchByTerm(String term) throws IOException
    {
        FileReader fr = new FileReader("U:\\computing\\definitions.txt");
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        String[]word = new String[10];
        int i = 0;
        boolean found = false;
        do {
            word[i]=(line);
            i = i + 2;
        }while ((line = br.readLine()) != null);
        br.close();
        i = 0;
        for (i=0; i<10; i=i+2){
            if (term == word[i]){
                System.out.println("FOUND" + word[i]);
                i++;
                System.out.println(word[i]);
                found = true;
            }
            if (found == false){
                System.out.println("TERM NOT FOUND");
            }
        }
    }
            public static void searchDescriptionsByKeyword(String term) throws IOException
    {
        FileReader fr = new FileReader("U:\\computing\\definitions.txt");
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        String[]word = new String[10];
        int i = 1;
        boolean found = false;
                do {
            word[i]=(line);
            i = i + 2;
        }while ((line = br.readLine()) != null);
        br.close();
        i = 1;
                for (i=0; i<10; i=i+2){
            if (term.contains(word[i])){
                System.out.println("FOUND" + word[i]);
                i++;
                System.out.println(word[i]);
                found = true;
            }
            if (found == false){
                System.out.println("TERM NOT FOUND");
            }
        }
    }
        public static void main(String[] args) throws IOException
        {
        Scanner input = new Scanner(System.in);
        System.out.println("1. Search for a term");
        System.out.println("2. Search for a key word in descriptions");
        System.out.println("3. End");
        System.out.println("Key in choice");
        int choice = input.nextInt();
 
        if (choice==1){
            System.out.println("Enter the term ");
            String term = input.nextLine();
            searchByTerm(term);
        }
        else if (choice==2){
            System.out.println("Enter the key word ");
            String keyword = input.nextLine();
            searchDescriptionsByKeyword(keyword);
        }
        else {
            System.out.println("Bye!");
        }
    }
}